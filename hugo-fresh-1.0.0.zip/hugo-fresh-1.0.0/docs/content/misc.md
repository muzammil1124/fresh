---
title: Misc
sidebar: true
sidebarlogo: fresh-white
include_footer: false
---

## Favicon

You can replace the default favicon by adding your own to `static/images/favicon.png`.
As for now, only pngs are possible.
