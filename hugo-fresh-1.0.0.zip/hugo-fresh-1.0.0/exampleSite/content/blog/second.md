---
title: Second
sidebar: true
sidebarlogo: fresh-white-alt
---

{{% title2 "My awesome blogpost" %}}
My super sweet second blog post
